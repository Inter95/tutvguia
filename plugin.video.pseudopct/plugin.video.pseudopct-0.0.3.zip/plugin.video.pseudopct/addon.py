﻿import sys
import urllib
import urlparse
import json

import xbmcgui
import xbmcplugin
import common

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
browser = common.Browser()
xbmcplugin.setContent(addon_handle, 'movies')
qua = {'0': '', '720p': '720p', '1080p': '1080p'}


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


mode = args.get('mode', None)

# first level
if mode is None:
    url = build_url({'mode': 'movies', 'page': '1'})
    li = xbmcgui.ListItem('Movies', iconImage='DefaultMovies.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'tvshows', 'page': '1'})
    li = xbmcgui.ListItem('TV Shows', iconImage='DefaultTVShows.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'anime', 'page': '1'})
    li = xbmcgui.ListItem('Anime', iconImage='Defaultvideo.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

# second level
else:
    mode = args['mode'][0]
    page = args['page'][0]
    quality = args.get('quality', None)
    IMDB = args.get('IMDB', None)
    seasons = args.get('seasons', 0)
    season = args.get('season', 0)
    poster = args.get('poster', None)
    fanart = args.get('fanart', None)

    if mode == 'movies':
        if quality is None:
            url = build_url({'mode': mode, 'page': page, 'quality': '720p'})
            li = xbmcgui.ListItem('720p', iconImage='Defaultvideo.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            url = build_url({'mode': mode, 'page': page, 'quality': '1080p'})
            li = xbmcgui.ListItem('1080p', iconImage='Defaultvideo.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            url = build_url({'mode': mode, 'page': page, 'quality': '3D'})
            li = xbmcgui.ListItem('3D', iconImage='Defaultvideo.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        else:
            # build menu with the movies
            url_search = "https://yts.to/api/v2/list_movies.json?sort_by=year&quality=%s&page=%s" % (quality[0], page)
            print url_search
            browser.open(url_search)
            data = json.loads(browser.content)
            for item in data['data']['movies']:
                for torrent in item['torrents']:
                    if torrent['quality'] == quality[0]:
                        url = 'plugin://plugin.video.pulsar/play?uri=%s' % torrent['url']
                        li = xbmcgui.ListItem(label=item['title'] + ' - ' + torrent['quality'],
                                              iconImage=item['medium_cover_image'],
                                              thumbnailImage=item['medium_cover_image'])
                        li.setInfo(type='Video',
                                   infoLabels={'title': item['title_long'], 'sorttitle': item['title'],
                                               'year': item['year'],
                                               'code': item['imdb_code'], 'mpaa': item['mpa_rating'],
                                               'rating': item['rating'],
                                               'genre': ' / '.join(item['genres']), 'duration': item['runtime'],
                                               'VideoResolution': torrent['quality']})
                        li.addStreamInfo('Video',
                                         {'language': item['language'], 'duration': item['runtime'],
                                          'Resolution': torrent['quality']
                                          })
                        li.setProperty('fanart_image', item['background_image'])
                        li.setProperty('IsPlayable', 'true')
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
            url = build_url({'mode': 'movies', 'quality': quality[0], 'page': int(page) + 1})
            li = xbmcgui.ListItem('Next Page...')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    elif mode == 'tvshows':
        if quality is None:
            url = build_url({'mode': mode, 'page': page, 'quality': '0'})
            li = xbmcgui.ListItem('HDTV', iconImage='Defaultvideo.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            url = build_url({'mode': mode, 'page': page, 'quality': '480p'})
            li = xbmcgui.ListItem('480p', iconImage='Defaultvideo.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            url = build_url({'mode': mode, 'page': page, 'quality': '720p'})
            li = xbmcgui.ListItem('720p', iconImage='Defaultvideo.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        else:
            # build menu with the tv shows
            url_search = "http://eztvapi.re/shows/%s" % page
            print url_search
            browser.open(url_search)
            data = json.loads(browser.content)
            for item in data:
                url = build_url({'mode': 'seasons', 'quality': quality[0], 'page': page, 'IMDB': item['imdb_id'],
                                 'seasons': item['num_seasons'], 'poster': item['images']['poster'],
                                 'fanart': item['images']['fanart']})
                li = xbmcgui.ListItem(label=item['title'], iconImage=item['images']['poster'],
                                      thumbnailImage=item['images']['poster'])
                li.setInfo(type='Video', infoLabels={'title': item['title'], 'year': item['year']})
                li.setProperty('fanart_image', item['images']['fanart'])
                li.setProperty('IsPlayable', 'false')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            url = build_url({'mode': 'tvshows', 'quality': quality[0], 'page': int(page) + 1, 'IMDB': item['imdb_id']})
            li = xbmcgui.ListItem('Next Page...')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    elif mode == 'seasons':
        # build menu with the seasons
        for season in range(1, int(seasons[0])):
            url = build_url({'mode': 'tvshow', 'quality': quality[0], 'page': page, 'IMDB': IMDB[0], 'season': season,
                             'poster': poster[0],
                             'fanart': fanart[0]})
            li = xbmcgui.ListItem(label='Season %s' % season, iconImage=poster[0], thumbnailImage=poster[0])
            li.setProperty('fanart_image', fanart[0])
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    elif mode == 'tvshow':
        # build menu with the episode tv shows
        url_search = "http://eztvapi.re/show/%s" % IMDB[0]
        browser.open(url_search)
        data = json.loads(browser.content)
        for episode in data['episodes']:
            if int(season[0]) == int(episode['season']):
                if episode['torrents'].has_key(quality[0]):
                    value_quality = quality[0]
                else:
                    value_quality = '0'
                url = 'plugin://plugin.video.pulsar/play?uri=%s' % episode['torrents'][value_quality]['url']
                li = xbmcgui.ListItem(
                    label=str(episode['episode']) + ' - ' + episode['title'] + ' - ' + qua[value_quality],
                    iconImage=poster[0], thumbnailImage=poster[0])
                li.setInfo(type='Video',
                           infoLabels={'title': episode['title'], 'sorttitle': episode['title'],
                                       'year': data['year'],
                                       'code': IMDB[0],
                                       'episode': episode['episode'],
                                       'season': episode['season'],
                                       'studio': data['network'],
                                       'plot': data['synopsis'],
                                       'rating': float(data['rating']['percentage']) / 10,
                                       'genre': ' / '.join(data['genres']), 'duration': data['runtime'],
                                       'VideoResolution': value_quality})
                li.addStreamInfo('Video',
                                 {'language': data['country'], 'duration': data['runtime'],
                                  'Resolution': value_quality
                                  })
                li.setProperty('fanart_image', fanart[0])
                li.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    elif mode == 'anime':
        if quality is None:
            url = build_url({'mode': mode, 'page': page, 'quality': '480p'})
            li = xbmcgui.ListItem('480p', iconImage='Defaultvideo.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            url = build_url({'mode': mode, 'page': page, 'quality': '720p'})
            li = xbmcgui.ListItem('720p', iconImage='Defaultvideo.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            url = build_url({'mode': mode, 'page': page, 'quality': '1080p'})
            li = xbmcgui.ListItem('1080p', iconImage='Defaultvideo.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        else:
            # build menu with the anime
            url_search = "http://ptp.haruhichan.com/list.php?sort=popularity&limit=50&type=All&page=%s&order=asc" % str(
                int(page) - 1)
            print url_search
            browser.open(url_search)
            data = json.loads(browser.content)
            for item in data:
                url = build_url(
                    {'mode': 'anime-ep', 'quality': quality[0], 'page': page, 'IMDB': item['id']})
                li = xbmcgui.ListItem(label=item['name'], iconImage=item['malimg'],
                                      thumbnailImage=item['malimg'])
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            url = build_url({'mode': 'anime', 'quality': quality[0], 'page': int(page) + 1, 'IMDB': item['id']})
            li = xbmcgui.ListItem('Next Page...')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    elif mode == 'anime-ep':
        # build menu with the episodes from anime
        url_search = "http://ptp.haruhichan.com/anime.php?id=%s" % IMDB[0]
        browser.open(url_search)
        data = json.loads(browser.content)
        for episode in data['episodes']:
            if quality[0] in episode['quality']:
                url = 'plugin://plugin.video.pulsar/play?uri=%s' % episode['magnet']
                li = xbmcgui.ListItem(label=episode['name'],
                                      iconImage=data['malimg'],
                                      thumbnailImage=data['malimg'])
                li.setInfo(type='Video',
                           infoLabels={'title': episode['name'], 'sorttitle': episode['name'],
                                       'rating': data['score'],
                                       'genre': data['genres'],
                                       'VideoResolution': quality[0]})
                li.addStreamInfo('Video', {'Resolution': quality[0]})
                li.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    # end of the directory
    xbmcplugin.endOfDirectory(addon_handle)
