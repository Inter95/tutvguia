﻿import sys
import urllib
import urlparse
import json

import xbmcgui
import xbmcplugin
import common

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
browser = common.Browser()
xbmcplugin.setContent(addon_handle, 'movies')


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)


mode = args.get('mode', None)

# first level
if mode is None:
    url = build_url({'mode': 'folder', 'foldername': 'movies', 'page': '1'})
    li = xbmcgui.ListItem('Movies', iconImage='DefaultMovies.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'folder', 'foldername': 'tvshows', 'page': '1'})
    li = xbmcgui.ListItem('TV Shows', iconImage='DefaultTVShows.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'folder', 'foldername': 'anime', 'page': '1'})
    li = xbmcgui.ListItem('Anime', iconImage='Defaultvideo.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

# second level
elif mode[0] == 'folder':
    foldername = args['foldername'][0]
    page = args['page'][0]
    quality = args.get('quality', None)

    if foldername == 'movies':
        if quality is None:
            url = build_url({'mode': 'folder', 'foldername': foldername, 'page': page, 'quality': '720p'})
            li = xbmcgui.ListItem('720p', iconImage='Defaultvideo.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            url = build_url({'mode': 'folder', 'foldername': foldername, 'page': page, 'quality': '1080p'})
            li = xbmcgui.ListItem('1080p', iconImage='Defaultvideo.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            url = build_url({'mode': 'folder', 'foldername': foldername, 'page': page, 'quality': '3D'})
            li = xbmcgui.ListItem('3D', iconImage='Defaultvideo.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        else:
            # build menu with the movies
            url_search = "https://yts.to/api/v2/list_movies.json?sort_by=year&quality=%s&page=%s" % (quality[0], page)
            print url_search
            browser.open(url_search)
            data = json.loads(browser.content)
            for item in data['data']['movies']:
                for torrent in item['torrents']:
                    if torrent['quality'] == quality[0]:
                        url = 'plugin://plugin.video.pulsar/play?uri=%s' % torrent['url']
                        li = xbmcgui.ListItem(label=item['title'] + ' - ' + torrent['quality'],
                                              iconImage=item['medium_cover_image'],
                                              thumbnailImage=item['medium_cover_image'])
                        li.setInfo(type='Video',
                                   infoLabels={'title': item['title_long'], 'sorttitle': item['title'],
                                               'year': item['year'],
                                               'code': item['imdb_code'], 'mpaa': item['mpa_rating'],
                                               'rating': item['rating'],
                                               'genre': ' '.join(item['genres']), 'duration': item['runtime'],
                                               'VideoResolution': torrent['quality']})
                        li.addStreamInfo('Video',
                                         {'language': item['language'], 'duration': item['runtime'], 'codec': 'divx',
                                          'Resolution': torrent['quality']
                                          })
                        li.setProperty('fanart_image', item['background_image'])
                        li.setProperty('IsPlayable', 'true')
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
            url = build_url({'mode': 'folder', 'foldername': 'movies', 'quality': quality[0], 'page': int(page) + 1})
            li = xbmcgui.ListItem('Next Page...')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    elif foldername == 'tvshows':
        url = 'plugin://plugin.video.pulsar/play?uri=magnet%3A%3Fxt%3Durn%3Abtih' \
              '%3Aysmtguguxs43p23uxq6oyfe6xzglnnad' \
              '%26tr%3Dhttp%3A%2F%2Fopen.nyaatorrents.info%3A6544%2Fannounce%26tr%3Dudp%3A%2F%2Fopen.demonii.com' \
              '%3A1337%2Fannounce%26tr%3Dudp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce'
        li = xbmcgui.ListItem('One Piece',
                              iconImage='https://s.ynet.io/assets/images/movies/inara_the_jungle_girl_2012'
                                        '/background'
                                        '.jpg",'
                                        '"small_cover_image":"https://s.ynet.io/assets/images/movies'
                                        '/inara_the_jungle_girl_2012/small-cover.jpg',
                              thumbnailImage='http://image.tmdb.org/t/p/w500/uul85aYvjulVKKRexjL3ui9zuuB.jpg')
        li.setInfo(type='Video', infoLabels={"Title": "Pulsar video", 'trailer' : 'http:://v.traileraddict.com/40472'})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    elif foldername == 'anime':
        url = 'plugin://plugin.video.pulsar/play?uri=magnet%3A%3Fxt%3Durn%3Abtih' \
              '%3Aysmtguguxs43p23uxq6oyfe6xzglnnad' \
              '%26tr%3Dhttp%3A%2F%2Fopen.nyaatorrents.info%3A6544%2Fannounce%26tr%3Dudp%3A%2F%2Fopen.demonii.com' \
              '%3A1337%2Fannounce%26tr%3Dudp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce'
        li = xbmcgui.ListItem('One Piece',
                              iconImage='https://s.ynet.io/assets/images/movies/inara_the_jungle_girl_2012'
                                        '/background'
                                        '.jpg",'
                                        '"small_cover_image":"https://s.ynet.io/assets/images/movies'
                                        '/inara_the_jungle_girl_2012/small-cover.jpg',
                              thumbnailImage='http://image.tmdb.org/t/p/w500/uul85aYvjulVKKRexjL3ui9zuuB.jpg')
        li.setInfo(type='Video', infoLabels={"Title": "Pulsar video"})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    xbmcplugin.endOfDirectory(addon_handle)
