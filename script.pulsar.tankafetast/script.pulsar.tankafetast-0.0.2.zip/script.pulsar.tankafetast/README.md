script.pulsar.tankafetast
=========================

TankaFetast Pulsar provider for XBMC
