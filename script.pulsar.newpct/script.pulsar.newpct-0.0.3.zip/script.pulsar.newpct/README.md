script.pulsar.newpct
====================
Provaider para la pagina Newpct. Spanish only
Update pulsar 0.4.1 
Movies and TvShows OK
