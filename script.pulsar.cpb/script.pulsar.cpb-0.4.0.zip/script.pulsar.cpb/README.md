script.pulsar.cpb
=================

CPasBien (French) Pulsar provider for XBMC

History : 
_________________
Version 0.2.0 : 
- Updated for Pulsar 0.2
- Use French title when available

Version 0.0.1
- Initial version for Pulsar 0.1
