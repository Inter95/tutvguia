# coding: utf-8
from tools import *
#import feedparser

storage = Storage(settings.storageName, type="dict")

# this read the settings
list_url_search = []
rep = 0

while rep < 7:
    rep = settings.dialog.select('Choose an Option:', ['Add a New [COLOR ffff9900]RSS[/COLOR]',
                                                       'Easy [COLOR ffff9900]RSS[/COLOR] creation',
                                                       'Modify Saved [COLOR ffff9900]RSS[/COLOR]',
                                                       'Remove a [COLOR ffff9900]RSS[/COLOR]',
                                                       'View Saved [COLOR ffff9900]RSS[/COLOR] list',
                                                       'Manual Search',
                                                       'Read RSS list and create .strm Files',
                                                       'Erase Folders',
                                                       '-SETTINGS',
                                                       '-HELP',
                                                       'Exit'])
    if rep == 0:  # Add a New RSS
        selection = settings.dialog.input('URL RSS:')
        name = ''
        while name is '':
            name = settings.dialog.input('Name to this RSS:').title()
        storage.database[name] = selection

    if rep == 1:  # Easy RSS creation
        search = settings.dialog.input('Search query:')
        if search != '':
            type = settings.dialog.select('Type:', ['General', 'Movie', 'TV'])
            if type == 0:  # General
                selection = settings.value["query"].replace('QUERY', quote_plus(search))
            elif type == 1:  # Movie
                selection = settings.value["queryMovie"].replace('QUERY', quote_plus(search))
            else:  # TV Show
                selection = settings.value["queryTv"].replace('QUERY', quote_plus(search))
            name = ''
            while name is '':
                name = settings.dialog.input('Name to this RSS:').title()
            storage.database[name] = selection

    if rep == 2:  # Modify RSS list
        List = [name + ": " + RSS for (name, RSS) in zip(storage.database.keys(), storage.database.values())]
        list_rep = settings.dialog.select('Shows', List + ['CANCEL'])
        if list_rep < len(List):
            name = storage.database.keys()[list_rep]
            storage.database[name] = settings.dialog.input('URL RSS:', storage.database[name])

    if rep == 3 and len(storage.database.keys()) > 0:  # Remove a RSS
        List = [name + ": " + RSS for (name, RSS) in zip(storage.database.keys(), storage.database.values())]
        list_rep = settings.dialog.select('Choose RSS to Remove', List + ['CANCEL'])
        if list_rep < len(List):
            if settings.dialog.yesno('', 'Do you want Remove %s?' % List[list_rep]):
                storage.remove(storage.database.keys()[list_rep])

    if rep == 4:  # View Saved RSS list
        List = [name + ": " + RSS for (name, RSS) in zip(storage.database.keys(), storage.database.values())]
        settings.dialog.select('Shows', List)

    if rep == 5:  # Manual Search
        search = settings.dialog.input('Search query:')
        if search != '':
            url_search = settings.value["query"] % quote_plus(search)
            # Begin reading
            magnet_search = []
            title_search = []
            acum = 0
            response = browser.get(url_search, verify=False)
            if response.status_codes == requests.codes.ok:
                items = re.findall('<item>(.*?)</item>', response.text, re.S)
                for item in items:
                    s_title = re.findall('title>(.*?)</title>', item)
                    s_link = re.findall(r'magnet:\?[^\'"\s<>\[\]]+', item)
                    if len(s_link) == 0:
                        s_link = re.findall(
                            r'http??[a-zA-Z0-9\.\/\?\:@\-_=#\[\]\s]+[.]torren[a-zA-Z0-9\.\/\?\:@\-_=#\[\]]+', item)
                    if len(s_link) == 0:
                        s_link = re.findall('<link>(.*?)</link>', item, re.S)
                    if len(s_link) != 0:
                        if len(s_title) > 0:
                            if s_title[0] != '':
                                title_search.append(s_title[0])
                                magnet_search.append(s_link[0])
                                acum += 1
                if acum == 0:
                    settings.notification('No Movies nor Shows nor Anime!!')
                else:
                    list_rep = settings.dialog.select('Choose File', title_search + ['CANCEL'])
                    if list_rep < len(title_search):
                        rep = 6  # exit
                        xbmc.executebuiltin(
                            "PlayMedia(plugin://plugin.video.pulsar/play?uri=%s)" % quote_plus(magnet_search[list_rep]))
            else:
                settings.log(">>>>>>>HTTP %s<<<<<<<" % response.status_code)
                settings.notification(message="HTTP %s" % response.status_code, force=True)

    if rep == 6:
        list_url_search = storage.database.values()
        # Begin reading
        for url_search in list_url_search:
            if url_search is not '':
                magnetsMovie = []
                titlesMovie = []
                magnetsShow = []
                titlesShow = []
                magnetsAnime = []
                titlesAnime = []
                settings.notification('Checking Online\n%s...' % url_search)
                settings.log(url_search)
                acum = 0
                response = browser.get(url_search, verify=False)
                if response.status_code == requests.codes.ok:
                    items = re.findall('<item>(.*?)</item>', response.text, re.S)
                    for item in items:
                        s_title = re.findall('title>(.*?)</title>', item)
                        s_link = re.findall(r'magnet:\?[^\'"\s<>\[\]]+', item)
                        if len(s_link) == 0:
                            s_link = re.findall(
                                r'http??[a-zA-Z0-9\.\/\?\:@\-_=#\[\]\s]+[.]torren[a-zA-Z0-9\.\/\?\:@\-_=#\[\]]+', item)
                        if len(s_link) == 0:
                            s_link = re.findall('<link>(.*?)</link>', item, re.S)
                        if len(s_link) != 0:
                            if len(s_title) > 0:
                                if s_title[0] != '':
                                    info = format_title(s_title[0])
                                    if 'MOVIE' in info['type']:
                                        titlesMovie.append(s_title[0])
                                        magnetsMovie.append(s_link[0])
                                        acum += 1
                                    if 'SHOW' in info['type']:
                                        titlesShow.append(s_title[0])
                                        magnetsShow.append(s_link[0])
                                        acum += 1
                                    if 'ANIME' in info['type']:
                                        titlesAnime.append(s_title[0])
                                        magnetsAnime.append(s_link[0])
                                        acum += 1
                    if acum == 0: settings.notification('No Movies nor Shows nor Anime!!')
                    if len(titlesMovie) > 0:
                        integration(filenames=titlesMovie, magnets=magnetsMovie, typeList='MOVIE',
                                    folder=settings.movieFolder, silence=True)
                    if len(titlesShow) > 0:
                        integration(filenames=titlesShow, magnets=magnetsShow, typeList='SHOW',
                                    folder=settings.showFolder, silence=True)
                    if len(titlesAnime) > 0:
                        integration(filenames=titlesAnime, magnets=magnetsAnime, typeList='ANIME',
                                    folder=settings.animeFolder, silence=True)
                else:
                    settings.log(">>>>>>>HTTP %s<<<<<<<" % response.status_code)
                    settings.notification(message="HTTP %s" % response.status_code, force=True)

    if rep == 7:  # Erase Folders
        selectionRemove = settings.dialog.select('Choose an Option:', ['Movies', 'TV Shows', 'Animes'])
        if selectionRemove == 0:
            removeDirectory(settings.movieFolder)
        elif selectionRemove == 1:
            removeDirectory(settings.showFolder)
        else:
            removeDirectory(settings.animeFolder)

    if rep == 8:  # Settings
        settings.settings.openSettings()
        del settings
        settings = Settings()

    if rep == 9:  # Help
        settings.dialog.ok("Help",
                           "Please, check this address to find the user's operation:\n[B]http://goo.gl/8nYU6R[/B]")
# save the dictionary
storage.save()

del settings
del storage
del browser