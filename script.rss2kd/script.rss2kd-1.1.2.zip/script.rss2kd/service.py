# coding: utf-8
from tools import *
from time import time
from time import asctime
from time import localtime
from time import strftime
from time import gmtime


def update_service():
    if settings.value['service'] == 'true':
        # Begin Service
        storage = Storage(settings.storageName, type="dict")
        list_url_search = storage.database.values()
        # Begin reading
        for url_search in list_url_search:
            if url_search is not '':
                magnetsMovie = []
                titlesMovie = []
                magnetsShow = []
                titlesShow = []
                magnetsAnime = []
                titlesAnime = []
                settings.notification('Checking Online\n%s...' % url_search)
                settings.log(url_search)
                acum = 0
                response = browser.get(url_search, verify=False)
                if response.status_code == requests.codes.ok:
                    items = re.findall('<item>(.*?)</item>', response.text, re.S)
                    for item in items:
                        s_title = re.findall('title>(.*?)</title>', item)
                        s_link = re.findall(r'magnet:\?[^\'"\s<>\[\]]+', item)
                        if len(s_link) == 0:
                            s_link = re.findall(
                                r'http??[a-zA-Z0-9\.\/\?\:@\-_=#\[\]\s]+[.]torren[a-zA-Z0-9\.\/\?\:@\-_=#\[\]]+', item)
                        if len(s_link) == 0:
                            s_link = re.findall('<link>(.*?)</link>', item, re.S)
                        if len(s_link) != 0:
                            if len(s_title) > 0:
                                if s_title[0] != '':
                                    info = format_title(s_title[0])
                                    if 'MOVIE' in info['type']:
                                        titlesMovie.append(s_title[0])
                                        magnetsMovie.append(s_link[0])
                                        acum += 1
                                    if 'SHOW' in info['type']:
                                        titlesShow.append(s_title[0])
                                        magnetsShow.append(s_link[0])
                                        acum += 1
                                    if 'ANIME' in info['type']:
                                        titlesAnime.append(s_title[0])
                                        magnetsAnime.append(s_link[0])
                                        acum += 1
                    if acum == 0: settings.notification('No Movies nor Shows nor Anime!!')
                    if len(titlesMovie) > 0:
                        integration(filenames=titlesMovie, magnets=magnetsMovie, typeList='MOVIE',
                                    folder=settings.movieFolder, silence=True)
                    if len(titlesShow) > 0:
                        integration(filenames=titlesShow, magnets=magnetsShow, typeList='SHOW',
                                    folder=settings.showFolder, silence=True)
                    if len(titlesAnime) > 0:
                        integration(filenames=titlesAnime, magnets=magnetsAnime, typeList='ANIME',
                                    folder=settings.animeFolder, silence=True)
                else:
                    settings.log(">>>>>>>HTTP %s<<<<<<<" % response.status_code)
                    settings.notification(message="HTTP %s" % response.status_code, force=True)


if settings.value['service'] == 'true':
    every = 28800  # seconds
    previous_time = time()
    settings.log("Persistent Update Service starting...")
    update_service()
    while (not xbmc.abortRequested) and settings.value["persistent"] == 'true':
        if time() >= previous_time + every:  # verification
            previous_time = time()
            update_service()
            settings.log('Update List at %s' % asctime(localtime(previous_time)))
            settings.log('Next Update in %s' % strftime("%H:%M:%S", gmtime(every)))
            update_service()
        sleep(1)

del settings
del browser
