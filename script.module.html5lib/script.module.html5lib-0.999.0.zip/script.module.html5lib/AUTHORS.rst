Credits
=======

``html5lib`` is written and maintained by:

- James Graham
- Geoffrey Sneddon
- Łukasz Langa


Patches and suggestions
-----------------------
(In chronological order, by first commit:)

- Anne van Kesteren
- Lachlan Hunt
- lantis63
- Sam Ruby
- Tim Fletcher
- Thomas Broyer
- Mark Pilgrim
- Philip Taylor
- Ryan King
- Edward Z. Yang
- fantasai
- Philip Jägenstedt
- Ms2ger
- Andy Wingo
- Andreas Madsack
- Karim Valiev
- Mohammad Taha Jahangir
- Juan Carlos Garcia Segovia
- Mike West
- Marc DM
