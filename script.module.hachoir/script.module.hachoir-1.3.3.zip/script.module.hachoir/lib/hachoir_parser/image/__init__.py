from hachoir_parser.image.bmp import BmpFile
from hachoir_parser.image.gif import GifFile
from hachoir_parser.image.ico import IcoFile
from hachoir_parser.image.jpeg import JpegFile
from hachoir_parser.image.pcx import PcxFile
from hachoir_parser.image.psd import PsdFile
from hachoir_parser.image.png import PngFile
from hachoir_parser.image.tga import TargaFile
from hachoir_parser.image.tiff import TiffFile
from hachoir_parser.image.wmf import WMF_File
from hachoir_parser.image.xcf import XcfFile

