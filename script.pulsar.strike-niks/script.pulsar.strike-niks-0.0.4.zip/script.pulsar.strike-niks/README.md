# General

This provider uses Strike Search API.

This provider can be used to search general content, movies or tv shows.

More informations can be found on https://getstrike.net/api/

