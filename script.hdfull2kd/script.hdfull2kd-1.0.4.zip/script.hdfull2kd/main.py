# coding: utf-8
import json
from urllib import quote_plus
import re

from xbmc import sleep
import tools




# this read the settings
settings = tools.Settings()
# define the browser
browser = tools.Browser()
option_list = ['Busqueda Manual', 'Películas Estreno', 'Películas Actualizadas', 'Todas las Películas',
               'Últimos Episodios']
option_list.extend(['-CONFIGURACIÓN', '-AYUDA', 'Salir'])
ret = settings.dialog.select('Opción:', option_list)
if ret == 0:
    search = settings.dialog.input('Name Movie:')
    if search is not '':
        url_search = '%s/ajax/search.php?q=%s' % (settings.url_address, quote_plus(search))
        if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...',
                                                                settings.icon, settings.time_noti)
        settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
        if browser.open(url_search):
            data = json.loads(browser.content)
            titles = []
            url_list = []
            meta = []
            for item in data:
                titles.append(item['title'])
                url_list.append(item['permalink'])
                meta.append(item['meta'])
            rep = settings.dialog.select('Which Movie:', titles + ['CANCEL'])
            if rep < len(titles):
                if 'Movie' in meta[ret]:
                    title = url_list[ret][url_list[ret].rfind("/") + 1:]  # get the original name
                    tools.int_pelisalacarta(channel="hdfull", titles=[title], url=[url_list[ret]],
                                            type_list='MOVIE', folder=settings.movie_folder,
                                            name_provider=settings.name_provider)
                else:
                    tools.int_pelisalacarta(channel="hdfull", titles=[titles[ret]], url=[url_list[ret]],
                                            type_list='SHOW',
                                            folder=settings.movie_folder, name_provider=settings.name_provider)
        else:
            settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
            settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
elif ret == 1:  # Peliculas estreno
    titles = []
    url_list = []
    url_search = "%s/peliculas-estreno" % settings.url_address
    settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
    if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...', settings.icon,
                                                            settings.time_noti)
    if browser.open(url_search):
        info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                          browser.content)
        for item in info:
            url_list.append(settings.url_address + '/pelicula/' + item[0])
            titles.append(item[0][item[0].rfind("/") + 1:])
    else:
        settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
        settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
    if len(titles) > 0:
        tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='MOVIE',
                                folder=settings.movie_folder, name_provider=settings.name_provider)
elif ret == 2:  # Peliculas actualizadas
    titles = []
    url_list = []
    url_search = "%s/peliculas-actualizadas" % settings.url_address
    settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
    if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...', settings.icon,
                                                            settings.time_noti)
    if browser.open(url_search):
        info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                          browser.content)
        for item in info:
            url_list.append(settings.url_address + '/pelicula/' + item[0])
            titles.append(item[0][item[0].rfind("/") + 1:])
    else:
        settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
        settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
    if len(titles) > 0:
        tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='MOVIE',
                                folder=settings.movie_folder, name_provider=settings.name_provider)
elif ret == 3:  # Todas las peliculas
    titles = []
    url_list = []
    settings.pages = settings.dialog.numeric(0, 'Number of Pages to download:')
    if settings.pages == '' or settings.pages == 0:
        settings.pages = "1"
    settings.pages = int(settings.pages)
    for page in range(1, settings.pages + 1):
        url_search = "%s/peliculas/date/%s" % (settings.url_address, page)
        settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
        if settings.time_noti > 0: settings.dialog.notification(settings.name_provider,
                                                                'Checking Online, Page %s...' % str(page + 1),
                                                                settings.icon, settings.time_noti)
        if browser.open(url_search):
            info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                              browser.content)
            for item in info:
                url_list.append(settings.url_address + '/pelicula/' + item[0])
                titles.append(item[0][item[0].rfind("/") + 1:])
        else:
            settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
            settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
        if page % 5 == 0: sleep(1)
    if len(titles) > 0:
        tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='MOVIE',
                                folder=settings.movie_folder, name_provider=settings.name_provider)
elif ret == 4:  # Ultimos Episodios
    titles = []
    url_list = []
    url_search = "%s/series/episodio" % settings.url_address
    settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
    if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...', settings.icon,
                                                            settings.time_noti)
    if browser.open(url_search):
        info = re.findall('<a class="link" href="%s/serie/(.*?)" title="(.*?)"' % settings.url_address,
                          browser.content)
        for item in info:

            url_list.append(settings.url_address + '/serie/' + item[0])
            temp = item[0].replace('/temporada-', ' S').replace('/episodio-','E')
            titles.append(temp[temp.rfind("/") + 1:])  # get the title
    else:
        settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
        settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
    if len(titles) > 0:
        tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='SHOW',
                                folder=settings.show_folder, name_provider=settings.name_provider)

# commun menu
elif ret == len(option_list) - 3:  # Settings
    settings.settings.openSettings()
    settings = tools.Settings()
elif ret == len(option_list) - 2:  # Help
    settings.dialog.ok("Ayuda", "El manual de operacion se encuentra en esta dirección:\n[B]http://goo.gl/0b44BY[/B]")

del settings
del browser
