# coding: utf-8
import json
from urllib import quote_plus
import re
from xbmc import sleep
import tools


# this read the settings
settings = tools.Settings()
# define the browser
browser = tools.Browser()
ret = settings.dialog.select('Opción:',
                             ['Busqueda Manual', 'Películas Estreno', 'Películas Actualizadas', 'Todas las Películas',
                              '-CONFIGURACIÓN', '-AYUDA', 'Salir'])
if ret == 0:
    search = settings.dialog.input('Name Movie:')
    if search is not '':
        url_search = '%s/ajax/search.php?q=%s' % (settings.url_address, quote_plus(search))
        if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...',
                                                                settings.icon, settings.time_noti)
        settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
        if browser.open(url_search):
            data = json.loads(browser.content)
            title = []
            url_list = []
            meta = []
            for item in data:
                title.append(item['title'])
                url_list.append(item['permalink'])
                meta.append(item['meta'])
            rep = settings.dialog.select('Which Movie:', title + ['CANCEL'])
            if rep < len(title):
                if 'Movie' in meta[ret]:
                    tools.int_pelisalacarta(channel="hdfull", title=[title[ret]], url=[url_list[ret]],
                                            type_list='MOVIE', folder=settings.movie_folder,
                                            name_provider=settings.name_provider)
                else:
                    tools.int_pelisalacarta(channel="hdfull", title=[title[ret]], url=[url_list[ret]], type_list='SHOW',
                                            folder=settings.movie_folder, name_provider=settings.name_provider)
        else:
            settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
            settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
elif ret == 1:  # Peliculas estreno
    title = []
    url_list = []
    url_search = "%s/peliculas-estreno" % settings.url_address
    settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
    if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...', settings.icon,
                                                            settings.time_noti)
    if browser.open(url_search):
        info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                          browser.content)
        url_list.extend([(settings.url_address + '/pelicula/' + item[0]) for item in info])
        title.extend([(item[1]) for item in info])
    else:
        settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
        settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
    if len(title) > 0:
        tools.int_pelisalacarta(channel="hdfull", title=title, url=url_list, type_list='MOVIE',
                                folder=settings.movie_folder, name_provider=settings.name_provider)
elif ret == 2:  # Peliculas actualizadas
    title = []
    url_list = []
    url_search = "%s/peliculas-actualizadas" % settings.url_address
    settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
    if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...', settings.icon,
                                                            settings.time_noti)
    if browser.open(url_search):
        info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                          browser.content)
        url_list.extend([(settings.url_address + '/pelicula/' + item[0]) for item in info])
        title.extend([(item[1]) for item in info])
    else:
        settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
        settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
    if len(title) > 0:
        tools.int_pelisalacarta(channel="hdfull", title=title, url=url_list, type_list='MOVIE',
                                folder=settings.movie_folder, name_provider=settings.name_provider)
elif ret == 3:  # Todas las peliculas
    title = []
    url_list = []
    settings.pages = settings.dialog.numeric(0, 'Number of Pages to download:')
    if settings.pages == '' or settings.pages == 0:
        settings.pages = "1"
    settings.pages = int(settings.pages)
    for page in range(1, settings.pages):
        url_search = "%s/peliculas/date/%s" % (settings.url_address, page)
        settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
        if settings.time_noti > 0: settings.dialog.notification(settings.name_provider,
                                                                'Checking Online, Page %s...' % str(page + 1),
                                                                settings.icon, settings.time_noti)
        if browser.open(url_search):
            info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                              browser.content)
            url_list.extend([(settings.url_address + '/pelicula/' + item[0]) for item in info])
            title.extend([(item[1]) for item in info])
        else:
            settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
            settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
        if page % 5 == 0: sleep(1)
    if len(title) > 0:
        tools.int_pelisalacarta(channel="hdfull", title=title, url=url_list, type_list='MOVIE',
                                folder=settings.movie_folder, name_provider=settings.name_provider)
elif ret == 4:  # Settings
    settings.settings.openSettings()
    settings = tools.Settings()
elif ret == 5:  # Help
    settings.dialog.ok("Ayuda", "El manual de operacion se encuentra en esta dirección:\n[B]http://goo.gl/0b44BY[/B]")

del settings
del browser
