# coding: utf-8
import json
from urllib import quote_plus
import re

from xbmc import sleep
import tools


######################################
#############   MAIN #################
######################################

# this read the settings
settings = tools.Settings()
# define the browser
browser = tools.Browser()
option_list = ['Busqueda Manual', 'Películas Estreno', 'Películas Actualizadas', 'Todas las Películas',
               'Peliculas por categoría', 'Últimos Episodios', 'Episodios Estreno', 'Episodios Actualizados',
               'Series por categoría']
option_list.extend(['-CONFIGURACIÓN', '-AYUDA', 'Salir'])
ret = settings.dialog.select('Opción:', option_list)
if ret == 0:
    search = settings.dialog.input('Name Movie:')
    if search is not '':
        url_search = '%s/ajax/search.php?q=%s' % (settings.url_address, quote_plus(search))
        if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...',
                                                                settings.icon, settings.time_noti)
        settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
        if browser.open(url_search):
            data = json.loads(browser.content)
            titles = []
            url_list = []
            meta = []
            for item in data:
                titles.append(item['title'])
                url_list.append(item['permalink'])
                meta.append(item['meta'])
            rep = settings.dialog.select('Which Movie:', titles + ['CANCEL'])
            if rep < len(titles):
                if 'Movie' in meta[ret]:
                    title = url_list[ret][url_list[ret].rfind("/") + 1:]  # get the original name
                    tools.int_pelisalacarta(channel="hdfull", titles=[title], url=[url_list[ret]],
                                            type_list='MOVIE', folder=settings.movie_folder,
                                            name_provider=settings.name_provider)
                else:
                    tools.int_pelisalacarta(channel="hdfull", titles=[titles[ret]], url=[url_list[ret]],
                                            type_list='SHOW',
                                            folder=settings.movie_folder, name_provider=settings.name_provider)
        else:
            settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
            settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
elif ret == 1:  # Peliculas estreno
    titles = []
    url_list = []
    url_search = "%s/peliculas-estreno" % settings.url_address
    settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
    if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...', settings.icon,
                                                            settings.time_noti)
    if browser.open(url_search):
        info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                          browser.content)
        for item in info:
            url_list.append(settings.url_address + '/pelicula/' + item[0])
            titles.append(item[0][item[0].rfind("/") + 1:])
    else:
        settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
        settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
    if len(titles) > 0:
        tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='MOVIE',
                                folder=settings.movie_folder, name_provider=settings.name_provider)
elif ret == 2:  # Peliculas actualizadas
    titles = []
    url_list = []
    url_search = "%s/peliculas-actualizadas" % settings.url_address
    settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
    if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...', settings.icon,
                                                            settings.time_noti)
    if browser.open(url_search):
        info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                          browser.content)
        for item in info:
            url_list.append(settings.url_address + '/pelicula/' + item[0])
            titles.append(item[0][item[0].rfind("/") + 1:])
    else:
        settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
        settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
    if len(titles) > 0:
        tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='MOVIE',
                                folder=settings.movie_folder, name_provider=settings.name_provider)
elif ret == 3:  # Todas las peliculas
    titles = []
    url_list = []
    settings.pages = settings.dialog.numeric(0, 'Number of Pages to download:')
    if settings.pages == '' or settings.pages == 0:
        settings.pages = "1"
    settings.pages = int(settings.pages)
    for page in range(1, settings.pages + 1):
        url_search = "%s/peliculas/date/%s" % (settings.url_address, page)
        settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
        if settings.time_noti > 0: settings.dialog.notification(settings.name_provider,
                                                                'Checking Online, Page %s...' % str(page + 1),
                                                                settings.icon, settings.time_noti)
        if browser.open(url_search):
            info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                              browser.content)
            for item in info:
                url_list.append(settings.url_address + '/pelicula/' + item[0])
                titles.append(item[0][item[0].rfind("/") + 1:])
        else:
            settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
            settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
        if page % 5 == 0: sleep(1)
    if len(titles) > 0:
        tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='MOVIE',
                                folder=settings.movie_folder, name_provider=settings.name_provider)
elif ret == 4:  # Peliculas por categoria
    list_categories = {"Acción": "action",
                  "Animación": "animation",
                  "Aventura": "adventure",
                  "Biografía": "biography",
                  "Bélico": "war",
                  "Ciencia Ficción": "science-fiction",
                  "Comedia": "comedy",
                  "Crimen": "crime",
                  "Deportes": "sport",
                  "Documental": "documentary",
                  "Drama": "drama",
                  "Familia": "family",
                  "Fantasía": "fantasy",
                  "Film-Noir": "film-noir",
                  "Historia": "history",
                  "indie": "Indie",
                  "Misterio": "mystery",
                  "Musical": "musical",
                  "Romance": "romance",
                  "Sci-Fi": "sci-fi",
                  "Suspenso": "thriller",
                  "Terror": "horror",
                  "Western": "western"}
    rep = settings.dialog.select('Categoria:', list_categories.keys())
    category = list_categories[list_categories.keys()[rep]]
    rep = settings.dialog.select('Ordenadas por:', ['Fecha', 'Rating IMDB'])
    sortBy = ['date', 'imdb_rating'][rep]
    titles = []
    url_list = []
    settings.pages = settings.dialog.numeric(0, 'Number of Pages to download:')
    if settings.pages == '' or settings.pages == 0:
        settings.pages = "1"
    settings.pages = int(settings.pages)
    for page in range(1, settings.pages + 1):
        url_search = "%s/tags-peliculas/%s/%s/%s" % (settings.url_address, category, sortBy, page)
        settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
        if settings.time_noti > 0: settings.dialog.notification(settings.name_provider,
                                                                'Checking Online, Page %s...' % str(page),
                                                                settings.icon, settings.time_noti)
        if browser.open(url_search):
            info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                              browser.content)
            for item in info:
                url_list.append(settings.url_address + '/pelicula/' + item[0])
                titles.append(item[0][item[0].rfind("/") + 1:])
        else:
            settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
            settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
        if page % 5 == 0: sleep(1)
    if len(titles) > 0:
        tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='MOVIE',
                                folder=settings.movie_folder, name_provider=settings.name_provider)
elif ret == 5:  # Ultimos Episodios
    titles = []
    url_list = []
    url_search = "%s/a/episodes" % settings.url_address
    settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
    if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...', settings.icon,
                                                            settings.time_noti)
    if browser.login(url_search, payload={"action": "latest", "start": "0", "limit": "24", "elang": "ALL"}):
        data = json.loads(browser.content)
        for item in data:
            url_list.append(
                settings.url_address + '/serie/' + item['permalink'] + '/temporada-' + item['season'] + '/episodio-' +
                item['episode'])
            titles.append(item['show']['title']['en'] + " S%sE%s" % (item['season'], item['episode']))  # get the title
    else:
        settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
        settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
    if len(titles) > 0:
        tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='SHOW',
                                folder=settings.show_folder, name_provider=settings.name_provider)
elif ret == 6:  # Episodios Estreno
    titles = []
    url_list = []
    url_search = "%s/a/episodes" % settings.url_address
    settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
    if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...', settings.icon,
                                                            settings.time_noti)
    if browser.login(url_search, payload={"action": "premiere", "start": "0", "limit": "24", "elang": "ALL"}):
        data = json.loads(browser.content)
        for item in data:
            url_list.append(
                settings.url_address + '/serie/' + item['permalink'] + '/temporada-' + item['season'] + '/episodio-' +
                item['episode'])
            titles.append(item['show']['title']['en'] + " S%sE%s" % (item['season'], item['episode']))  # get the title
    else:
        settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
        settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
    if len(titles) > 0:
        tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='SHOW',
                                folder=settings.show_folder, name_provider=settings.name_provider)
elif ret == 7:  # Episodios Actualizados
    titles = []
    url_list = []
    url_search = "%s/a/episodes" % settings.url_address
    settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
    if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...', settings.icon,
                                                            settings.time_noti)
    if browser.login(url_search, payload={"action": "updated", "start": "0", "limit": "24", "elang": "ALL"}):
        data = json.loads(browser.content)
        for item in data:
            url_list.append(
                settings.url_address + '/serie/' + item['permalink'] + '/temporada-' + item['season'] + '/episodio-' +
                item['episode'])
            titles.append(item['show']['title']['en'] + " S%sE%s" % (item['season'], item['episode']))  # get the title
    else:
        settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
        settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
    if len(titles) > 0:
        tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='SHOW',
                                folder=settings.show_folder, name_provider=settings.name_provider)
elif ret == 8:  # Series por categoria
    list_categories = {"Acción": "action",
                  "Animación": "animation",
                  "Anime": "anime",
                  "Aventura": "adventure",
                  "Ciencia Ficción": "science-fiction",
                  "Comedia": "comedy",
                  "Crimen": "crime",
                  "Deportes": "sport",
                  "Documental": "documentary",
                  "Drama": "drama",
                  "Fantasía": "fantasy",
                  "Infantil": "children",
                  "Miniseries": "miniserie",
                  "Misterio": "mistery",
                  "Noticias": "news",
                  "Novela": "soap",
                  "Reality Show": "reality",
                  "Talk Show": "talk-show",
                  "Western": "western"}
    rep = settings.dialog.select('Categoria:', list_categories.keys())
    category = list_categories[list_categories.keys()[rep]]
    rep = settings.dialog.select('Ordenadas por:', ['Fecha', 'Rating IMDB'])
    sortBy = ['date', 'imdb_rating'][rep]
    titles = []
    url_list = []
    settings.pages = settings.dialog.numeric(0, 'Number of Pages to download:')
    if settings.pages == '' or settings.pages == 0:
        settings.pages = "1"
    settings.pages = int(settings.pages)
    for page in range(1, settings.pages + 1):
        url_search = "%s/tags-tv/%s/%s/%s" % (settings.url_address, category, sortBy, page)
        settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
        if settings.time_noti > 0: settings.dialog.notification(settings.name_provider,
                                                                'Checking Online, Page %s...' % str(page),
                                                                settings.icon, settings.time_noti)
        if browser.open(url_search):
            info = re.findall('<a class="link" href="%s/serie/(.*?)" title="(.*?)"' % settings.url_address,
                              browser.content)
            for itemdata in info:
                url_serie = settings.url_address + '/serie/' + itemdata[0]
                if settings.time_noti > 0: settings.dialog.notification(settings.name_provider,
                                                                        'Checking Online, %s' % itemdata[0][itemdata[0].rfind("/") + 1:],
                                                                        settings.icon, settings.time_noti)
                browser.open(url_serie)  # open the serie
                seasons = re.findall("/temporada-(.*?)'", browser.content)
                seasons = list(set(seasons))
                sid = re.findall("var sid = '(.*?)'", browser.content)[0]
                for season in seasons:
                    url_search = "%s/a/episodes" % settings.url_address
                    if browser.login(url_search,
                                     payload={"action": "season", "start": "0", "limit": "0", "show": sid, "season": season}):
                        data = json.loads(browser.content)
                        for item in data:
                            url_list.append(
                                settings.url_address + '/serie/' + item['permalink'] + '/temporada-' + item[
                                    'season'] + '/episodio-' +
                                item['episode'])
                            titles.append(item['show']['title']['en'] + " S%sE%s" % (
                            item['season'], item['episode']))  # get the title
        else:
            settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
            settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
        if page % 5 == 0: sleep(1)
    if len(titles) > 0:
        tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='SHOW',
                                folder=settings.show_folder, name_provider=settings.name_provider)

        # commun menu
elif ret == len(option_list) - 3:  # Settings
    settings.settings.openSettings()
    settings = tools.Settings()
elif ret == len(option_list) - 2:  # Help
    settings.dialog.ok("Ayuda", "El manual de operacion se encuentra en esta dirección:\n[B]http://goo.gl/0b44BY[/B]")

del settings
del browser
