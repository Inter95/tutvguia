# coding: utf-8
import re
import tools
import json
from time import time
from time import asctime
from time import localtime
from time import strftime
from time import gmtime
from xbmc import log
from xbmc import sleep
from xbmc import abortRequested
from xbmcaddon import Addon


def update_service():
    # this read the settings
    settings = tools.Settings()
    # define the browser
    browser = tools.Browser()
    #Begin Service
    if settings.service == 'true':
        if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...', settings.icon, settings.time_noti)
        if Addon().getSetting('peliculasEstreno') == 'true':  # Peliculas estreno
            titles = []
            url_list = []
            url_search = "%s/peliculas-estreno" % settings.url_address
            settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
            if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...',
                                                                    settings.icon,
                                                                    settings.time_noti)
            if browser.open(url_search):
                info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                                  browser.content)
                for item in info:
                    url_list.append(settings.url_address + '/pelicula/' + item[0])
                    titles.append(item[0][item[0].rfind("/") + 1:])
            else:
                settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
                settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
            if len(titles) > 0:
                tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='MOVIE',
                                        folder=settings.movie_folder, name_provider=settings.name_provider, silence=True)
        elif Addon().getSetting('peliculasActualizadas') == 'true':  # Peliculas actualizadas
            titles = []
            url_list = []
            url_search = "%s/peliculas-actualizadas" % settings.url_address
            settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
            if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...',
                                                                    settings.icon,
                                                                    settings.time_noti)
            if browser.open(url_search):
                info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                                  browser.content)
                for item in info:
                    url_list.append(settings.url_address + '/pelicula/' + item[0])
                    titles.append(item[0][item[0].rfind("/") + 1:])
            else:
                settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
                settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
            if len(titles) > 0:
                tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='MOVIE',
                                        folder=settings.movie_folder, name_provider=settings.name_provider, silence=True)
        elif Addon().getSetting('todasPeliculas') == 'true':  # Todas las peliculas
            titles = []
            url_list = []
            settings.pages = settings.dialog.numeric(0, 'Number of Pages to download:')
            if settings.pages == '' or settings.pages == 0:
                settings.pages = "1"
            settings.pages = int(settings.pages)
            for page in range(1, settings.pages + 1):
                url_search = "%s/peliculas/date/%s" % (settings.url_address, page)
                settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
                if settings.time_noti > 0: settings.dialog.notification(settings.name_provider,
                                                                        'Checking Online, Page %s...' % str(page),
                                                                        settings.icon, settings.time_noti)
                if browser.open(url_search):
                    info = re.findall('<a class="link" href="%s/pelicula/(.*?)" title="(.*?)"' % settings.url_address,
                                      browser.content)
                    for item in info:
                        url_list.append(settings.url_address + '/pelicula/' + item[0])
                        titles.append(item[0][item[0].rfind("/") + 1:])
                else:
                    settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
                    settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
                if page % 5 == 0: sleep(1)
            if len(titles) > 0:
                tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='MOVIE',
                                        folder=settings.movie_folder, name_provider=settings.name_provider, silence=True)
        elif Addon().getSetting('episodioEstreno') == 'true':  # Ultimos Episodios
            titles = []
            url_list = []
            url_search = "%s/a/episodes" % settings.url_address
            settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
            if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...',
                                                                    settings.icon,
                                                                    settings.time_noti)
            if browser.login(url_search, payload={"action": "latest", "start": "0", "limit": "24", "elang": "ALL"}):
                data = json.loads(browser.content)
                for item in data:
                    url_list.append(settings.url_address + '/serie/' + item['permalink'] + '/temporada-' + item[
                        'season'] + '/episodio-' + item['episode'])
                    titles.append(
                        item['show']['title']['en'] + "S%sE%s" % (item['season'], item['episode']))  # get the title
            else:
                settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
                settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
            if len(titles) > 0:
                tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='SHOW',
                                        folder=settings.show_folder, name_provider=settings.name_provider, silence=True)
        elif Addon().getSetting('premiereEpisodio') == 'true':  # Episodios Estreno
            titles = []
            url_list = []
            url_search = "%s/a/episodes" % settings.url_address
            settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
            if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...',
                                                                    settings.icon,
                                                                    settings.time_noti)
            if browser.login(url_search, payload={"action": "premiere", "start": "0", "limit": "24", "elang": "ALL"}):
                data = json.loads(browser.content)
                for item in data:
                    url_list.append(settings.url_address + '/serie/' + item['permalink'] + '/temporada-' + item[
                        'season'] + '/episodio-' + item['episode'])
                    titles.append(
                        item['show']['title']['en'] + "S%sE%s" % (item['season'], item['episode']))  # get the title
            else:
                settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
                settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
            if len(titles) > 0:
                tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='SHOW',
                                        folder=settings.show_folder, name_provider=settings.name_provider, silence=True)
        elif Addon().getSetting('actualizadosEpisodes') == 'true':  # Episodios Actualizados
            titles = []
            url_list = []
            url_search = "%s/a/episodes" % settings.url_address
            settings.log('[%s] %s' % (settings.name_provider_clean, url_search))
            if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...',
                                                                    settings.icon,
                                                                    settings.time_noti)
            if browser.login(url_search, payload={"action": "updated", "start": "0", "limit": "24", "elang": "ALL"}):
                data = json.loads(browser.content)
                for item in data:
                    url_list.append(settings.url_address + '/serie/' + item['permalink'] + '/temporada-' + item[
                        'season'] + '/episodio-' + item['episode'])
                    titles.append(
                        item['show']['title']['en'] + "S%sE%s" % (item['season'], item['episode']))  # get the title
            else:
                settings.log('[%s] >>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
                settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
            if len(titles) > 0:
                tools.int_pelisalacarta(channel="hdfull", titles=titles, url=url_list, type_list='SHOW',
                                        folder=settings.show_folder, name_provider=settings.name_provider, silence=True)

    del settings
    del browser


if Addon().getSetting('service') == 'true':
    persistent = Addon().getSetting('persistent')
    name_provider = re.sub('.COLOR (.*?)]', '', Addon().getAddonInfo('name').replace('[/COLOR]', ''))
    every = 28800  # seconds
    previous_time = time()
    log("[%s]Update Service starting..." % name_provider)
    update_service()
    while (not abortRequested) and persistent == 'true':
        if time() >= previous_time + every:  # verification
            previous_time = time()
            update_service()
            log('[%s] Update List at %s' % (name_provider, asctime(localtime(previous_time))))
            log('[%s] Next Update in %s' % (name_provider, strftime("%H:%M:%S", gmtime(every))))
            update_service()
        sleep(500)
