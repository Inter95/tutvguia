# coding: utf-8
from tools import *
import bs4
import requests

categories = {'Movies Popular': 'http://trakt.tv/movies/popular',
              'Movies Trending': 'http://trakt.tv/movies/trending',
              'TV Popular': 'http://trakt.tv/shows/popular',
              'TV trending': 'http://trakt.tv/shows/trending',
              'Watchlist': '',
              'List': ''
              }
options = categories.keys()
options.sort()

lists = []
ret = settings.dialog.select('Choose a category:', options + ['Erase Folder','-SETTINGS', '-HELP', 'Exit'])

if ret < len(options):  # Exit
    if options[ret] == 'Watchlist':  # WatchList
        user = settings.dialog.input('Username:', settings.value["user"])
        categories[options[ret]] = 'http://trakt.tv/users/%s/watchlist' % settings.value["user"].lower()

    if options[ret] == 'List':  # List
        user = settings.dialog.input('Username:', settings.value["user"])
        # password = settings.dialog.input('Password:', password, option=2)
        # browser.open('http://trakt.tv/auth/signin')
        # token = re.search('name="authenticity_token" value="(.*?)"', browser.content).group(1)
        # print '************************************'
        # print token
        # browser.login('http://trakt.tv/auth/signin', {'utf8': '&#x2713;', 'user[login]': user,
        # 'user[password]': password, 'commit': 'Sign in',
        # 'user[remember_me]': 1,
        # 'authenticity_token': token})
        categories[options[ret]] = "http://trakt.tv"
        response = browser.get('http://trakt.tv/users/%s/lists/' % settings.value["user"].lower())
        soup = bs4.BeautifulSoup(response.text)
        links = soup.select("div.row.custom-list div.user-name > a:nth-of-type(1)")
        for link in links:
            lists.append(link.attrs.get("href"))

    # main
    url_search = categories[options[ret]]  # define the url search
    if url_search is not '':
        listing = []
        ID = []  # IMDB_ID or thetvdb ID
        cm = 0
        while True:
            settings.notification("Checking Online...")
            if len(lists) > 0:
                settings.log(url_search + lists[cm])
                response = browser.get(url_search + lists[cm])
                settings.log(url_search + lists[cm])
            else:
                settings.log(url_search)
                response = browser.get(url_search)
                settings.log(url_search)

            if response.status_code == requests.codes.ok:
                titlesMovies = []
                titlesShows = []

                soup = bs4.BeautifulSoup(response.text)
                links = soup.select("div.row.fanarts div.grid-item > a")
                if len(links) == 0:  # it is the list
                    links = soup.select("div.row.posters div.grid-item > a")

                for link in links:
                    subLinks = link.select('div.titles h3')
                    if len(subLinks) > 0:
                        url = link.attrs.get("href")
                        title = subLinks[0].text
                        if "movies" in url:
                            titlesMovies.append(title)
                        else:
                            titlesShows.append(title)

                if len(titlesMovies) > 0:  # there is movies
                    subscription(listing=titlesMovies, ID=ID, typeList='MOVIE', folder=settings.movieFolder)

                if len(titlesShows) > 0:  # there is tv shows
                    subscription(listing=titlesShows, ID=ID, typeList='SHOW', folder=settings.showFolder)
            else:
                settings.log(">>>>>>>HTTP %s<<<<<<<" % response.status_code)
                settings.notification(message="HTTP %s" % response.status_code, force=True)
                break

            cm += 1
            if cm >= len(lists): break

if ret == len(options):  # Erase Folder
    selectionRemove = settings.dialog.select('Choose an Option:', ['Movies', 'TV Shows', 'Animes'])
    if selectionRemove == 0:
        removeDirectory(settings.movieFolder)
    else:
        removeDirectory(settings.showFolder)

if ret == len(options) + 1:  # Settings
    settings.settings.openSettings()

if ret == len(options) + 2:  # Help
    settings.dialog.ok("Help", "Please, check this address to find the user's operation:\n[B]http://goo.gl/8nYU6R[/B]")

del settings
del browser
